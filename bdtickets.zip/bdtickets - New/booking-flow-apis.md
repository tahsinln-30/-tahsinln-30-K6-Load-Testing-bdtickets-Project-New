# BDTickets Booking Flow APIs

Base URLs (staging):

- **AAUM (auth):** `https://api1.bdtickets.tech:20100`
- **Booking:** `https://api1.bdtickets.tech:20102`

Common response envelope (`APIResponse`):

```json
{
  "message": null,
  "errors": null,
  "data": {},
  "version": 1,
  "timestamp": 1720000000
}
```

---

## 1. Generate Token (v2)

| Field | Value |
|--------|--------|
| **Method** | `POST` |
| **URL** | `https://api1.bdtickets.tech:20100/v2/auth` |
| **Service** | aaum (`https://api1.bdtickets.tech:20100`) |
| **Auth** | Public (no token) |

**Headers**

```
Content-Type: application/json
Accept: application/json
```

**Request Body** (password login)

```json
{
  "phoneNumber": "8801XXXXXXXXX",
  "password": "yourPassword",
  "applicationChannel": "WEB_APP"
}
```

Alternate (OTP):

```json
{
  "phoneNumber": "8801XXXXXXXXX",
  "code": "123456",
  "applicationChannel": "WEB_APP"
}
```

Or email + password / email + code.

**Response** (`data` = `AuthResponse`)

```json
{
  "message": null,
  "errors": null,
  "data": {
    "access": {
      "token": "<JWT>",
      "expires": 1720000300
    }
  },
  "version": 2,
  "timestamp": 1720000000
}
```

---

## 2. Refresh Token (v2)

| Field | Value |
|--------|--------|
| **Method** | `POST` |
| **URL** | `https://api1.bdtickets.tech:20100/v2/auth/refresh` |
| **Service** | aaum (`https://api1.bdtickets.tech:20100`) |
| **Auth** | Public |

**Headers**

```
Content-Type: application/json
Accept: application/json
```

**Request Body**

```json
{
  "token": "<existing JWT>"
}
```

**Response**

```json
{
  "message": "TOKEN_REFRESHED",
  "errors": null,
  "data": {
    "access": {
      "token": "<new JWT>",
      "expires": 1720000600
    }
  },
  "version": 2,
  "timestamp": 1720000000
}
```

---

## 3. Coach Search with Identifier (v3)

| Field | Value |
|--------|--------|
| **Method** | `POST` |
| **URL** | `https://api1.bdtickets.tech:20102/v3/coaches/search` |
| **Service** | booking (`https://api1.bdtickets.tech:20102`) |
| **Auth** | Required (`Bearer` JWT) |

Route is resolved by `identifier` when `routeId` / station IDs are absent.

**Headers**

```
Content-Type: application/json
Accept: application/json
Authorization: Bearer <JWT>
```

**Request Body**

```json
{
  "date": "2026-08-15",
  "identifier": "DHK-CTG",
  "returnExist": false,
  "structureType": "BUS",
  "tenantId": null,
  "channel": "WEB_APP"
}
```

Other optional fields: `routeId`, `fromStationId`, `toStationId`.

**Response** (`data` = list of `Coach`)

```json
{
  "message": null,
  "errors": null,
  "data": [
    {
      "id": "66abc...",
      "date": "2026-08-15",
      "routeId": "...",
      "coachNo": "101-DHK-CTG",
      "coachType": "AC",
      "company": { "id": "...", "name": "..." },
      "availableSeats": 28,
      "departureTime": "22:30",
      "arrivalTime": "06:00",
      "fares": { "E-Class": "1200" },
      "boardingPoints": [],
      "droppingPoints": [],
      "apiProvider": "BUSBD"
    }
  ],
  "version": 1,
  "timestamp": 1720000000
}
```

---

## 4. Coach Details (v3)

Seat layout / live seat status (typical “details” step after search).

| Field | Value |
|--------|--------|
| **Method** | `GET` |
| **URL** | `https://api1.bdtickets.tech:20102/v3/coaches/{id}/seats` |
| **Service** | booking (`https://api1.bdtickets.tech:20102`) |
| **Auth** | Required |

Static coach record (no live seats): `GET https://api1.bdtickets.tech:20102/v3/coaches/{id}`

**Headers**

```
Accept: application/json
Authorization: Bearer <JWT>
```

**Request Body**

None

**Response** (`data` = provider seat layout / coach seats; shape varies by `apiProvider`)

```json
{
  "message": null,
  "errors": null,
  "data": {
    "id": "66abc...",
    "coachNo": "101-DHK-CTG",
    "seats": [
      {
        "seatId": "12",
        "seatNo": "A1",
        "status": "AVAILABLE",
        "fare": 1200
      }
    ],
    "boardingPoints": [],
    "droppingPoints": [],
    "apiProvider": "BUSBD"
  },
  "version": 1,
  "timestamp": 1720000000
}
```

---

## 5. Cart Create (v3)

| Field | Value |
|--------|--------|
| **Method** | `POST` |
| **URL** | `https://api1.bdtickets.tech:20102/v3/carts` |
| **Service** | booking (`https://api1.bdtickets.tech:20102`) |
| **Auth** | Required |
| **HTTP status** | `201 Created` |

**Headers**

```
Content-Type: application/json
Accept: application/json
Authorization: Bearer <JWT>
```

**Request Body**

```json
{
  "bookApplication": "BUS",
  "applicationChannel": "WEB_APP"
}
```

**Response** (`data` = `Cart`)

```json
{
  "message": null,
  "errors": null,
  "data": {
    "id": "66cart...",
    "userId": "66user...",
    "userInfo": { "userId": "66user...", "phoneNumber": "8801..." },
    "bookApplication": "BUS",
    "applicationChannel": "WEB_APP",
    "passengerList": [],
    "coachSeatList": []
  },
  "version": 1,
  "timestamp": 1720000000
}
```

---

## 6. Cart Update (v3)

| Field | Value |
|--------|--------|
| **Method** | `PUT` |
| **URL** | `https://api1.bdtickets.tech:20102/v3/carts/{id}` |
| **Service** | booking (`https://api1.bdtickets.tech:20102`) |
| **Auth** | Required |

Used to attach coach/seats, boarding/dropping points, passengers, related carts, etc.

**Headers**

```
Content-Type: application/json
Accept: application/json
Authorization: Bearer <JWT>
```

**Request Body** (seat selection example)

```json
{
  "coachId": "66abc...",
  "seatIdList": ["12", "13"],
  "boardingPoint": 101,
  "droppingPoint": 205,
  "cartType": "DEPARTURE",
  "journeyDate": "2026-08-15",
  "applicationChannel": "WEB_APP",
  "passengerList": [
    {
      "firstName": "Rahim",
      "lastName": "Uddin",
      "gender": "MALE",
      "phoneNumber": "8801XXXXXXXXX",
      "email": "rahim@example.com"
    }
  ],
  "remove": false,
  "includeTravelInsurance": false
}
```

**Response** (`data` = updated `Cart` with seats, fares, boarding points, pricing, etc.)

```json
{
  "message": null,
  "errors": null,
  "data": {
    "id": "66cart...",
    "coachId": "66abc...",
    "coachNo": "101-DHK-CTG",
    "journeyDate": "2026-08-15",
    "boardingPoint": 101,
    "droppingPoint": 205,
    "coachSeatList": [
      { "seatId": "12", "seatNo": "A1", "fare": 1200 }
    ],
    "passengerList": [],
    "apiProvider": "BUSBD"
  },
  "version": 1,
  "timestamp": 1720000000
}
```

---

## 7. Book (v3)

| Field | Value |
|--------|--------|
| **Method** | `POST` |
| **URL** | `https://api1.bdtickets.tech:20102/v3/carts/book` |
| **Service** | booking (`https://api1.bdtickets.tech:20102`) |
| **Auth** | Required (cart owner, or admin / `ORDER_CREATE_OTHERS`) |

**Headers**

```
Content-Type: application/json
Accept: application/json
Authorization: Bearer <JWT>
```

**Request Body**

```json
{
  "cartId": "66cart...",
  "applicationChannel": "WEB_APP",
  "selectedPaymentMethod": "WALLET",
  "isPaymentFollowing": false,
  "termsAgreed": true,
  "requireDto": true,
  "isTestBooking": false
}
```

**Response** (`data` = `TicketDto`)

```json
{
  "message": null,
  "errors": null,
  "data": {
    "id": "66ticket...",
    "ticketNo": "BDT123456",
    "userId": "66user...",
    "cartId": "66cart...",
    "totalAmount": 2400,
    "grandTotalAmount": 2450,
    "totalPayable": 2450,
    "ticketStatus": { "name": "BOOKED", "payable": true },
    "passengerList": [],
    "trips": [],
    "expireTime": "2026-08-02T12:00:00"
  },
  "version": 1,
  "timestamp": 1720000000
}
```

---

## 8. Confirm (v3)

| Field | Value |
|--------|--------|
| **Method** | `POST` |
| **URL** | `https://api1.bdtickets.tech:20102/v3/tickets/confirm` |
| **Service** | booking (`https://api1.bdtickets.tech:20102`) |
| **Auth** | Required |

**Headers**

```
Content-Type: application/json
Accept: application/json
Authorization: Bearer <JWT>
```

**Request Body** (wallet)

```json
{
  "ticketId": "66ticket...",
  "accountType": "WALLET",
  "applicationChannel": "WEB_APP",
  "requireDto": true,
  "debug": false,
  "paymentInfo": {
    "paymentGateway": "WALLET",
    "value": 2450
  }
}
```

PGW example:

```json
{
  "ticketId": "66ticket...",
  "accountType": "WALLET",
  "applicationChannel": "WEB_APP",
  "paymentInfo": {
    "transactionId": "txn_internal_id",
    "extId": "pgw_external_id",
    "value": 2450,
    "paymentGateway": "BKASH",
    "dateTime": "2026-08-02T11:30:00"
  }
}
```

**Response** (`data` = confirmed `TicketDto`)

```json
{
  "message": null,
  "errors": null,
  "data": {
    "id": "66ticket...",
    "ticketNo": "BDT123456",
    "cartId": "66cart...",
    "totalPayable": 2450,
    "ticketStatus": { "name": "CONFIRMED", "payable": false },
    "passengerList": [],
    "trips": []
  },
  "version": 1,
  "timestamp": 1720000000
}
```

---

## Suggested call order

1. Generate Token  
2. (optional) Refresh Token  
3. Coach Search with Identifier  
4. Coach Details / Seats  
5. Cart Create  
6. Cart Update  
7. Book  
8. Confirm  

## Notes

- JWT header: `Authorization: Bearer <token>` (`core.jwt.header-name` / `token-prefix`).
- Booking security currently permits only `/v1/**` without auth; **v3 booking APIs need a valid JWT**.
- `applicationChannel` on confirm must match the cart’s channel.
- Enum samples: `BookApplication.BUS`, `ApplicationChannel.WEB_APP`, `AccountType.WALLET`, `TicketType.DEPARTURE|RETURN`, `PaymentGateway.WALLET|BKASH|...`.
