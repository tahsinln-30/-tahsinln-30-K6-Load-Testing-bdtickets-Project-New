import http from 'k6/http';
import { check, sleep } from 'k6';
import { SharedArray } from 'k6/data';
import { Counter } from 'k6/metrics';

// 500 concurrent users: Login → Search → random Coach → random Seat → Book
// Target completion window: 5–10 minutes
export const options = {
    scenarios: {
        concurrent_booking: {
            executor: 'per-vu-iterations',
            vus: 500,
            iterations: 1,
            maxDuration: '10m',
            gracefulStop: '30s',
        },
    },
};

const AUTH_URL = 'https://api1.bdtickets.tech:20100';
const BOOKING_URL = 'https://api1.bdtickets.tech:20102';

const JOURNEY_DATE = '2026-08-22';
const ROUTE_IDENTIFIER = 'dhaka-to-bandarban';

// How many random coach attempts per user before giving up
const MAX_COACH_TRIES = 12;
// How many random seats to try on a chosen coach
const MAX_SEAT_TRIES = 8;

const loginSuccess = new Counter('login_success');
const loginFail = new Counter('login_fail');
const bookSuccess = new Counter('book_success');
const bookFail = new Counter('book_fail');

const USERS_CSV = __ENV.USERS_CSV || 'loadtest-users.csv';

const users = new SharedArray('users', function () {
    const text = open(USERS_CSV);
    const lines = text.replace(/^\uFEFF/, '').trim().split(/\r?\n/);
    if (lines.length < 2) throw new Error(`No users found in ${USERS_CSV}`);

    const headers = lines[0].split(',').map((h) => h.trim());
    const phoneIdx = headers.indexOf('phoneNumber');
    const passIdx = headers.indexOf('password');
    const idIdx = headers.indexOf('userId');
    if (phoneIdx < 0 || passIdx < 0) {
        throw new Error('CSV must have phoneNumber and password columns');
    }

    const parsed = [];
    for (let i = 1; i < lines.length; i++) {
        const cols = lines[i].split(',');
        if (cols.length < 2) continue;

        const phone = normalizePhone((cols[phoneIdx] || '').trim(), i);
        const password = (cols[passIdx] || '').trim();
        if (!phone || !password) continue;

        parsed.push({
            phoneNumber: phone,
            password: password,
            userId: idIdx >= 0 ? (cols[idIdx] || '').trim() : '',
            email: `loadtest${i}@example.com`,
            firstName: 'Load',
            lastName: `User${i}`,
        });
    }

    if (!parsed.length) throw new Error(`Failed to parse users from ${USERS_CSV}`);
    console.log(`Loaded ${parsed.length} users from ${USERS_CSV}`);
    return parsed;
});

function normalizePhone(raw, rowIndex) {
    let p = String(raw || '').trim();
    if (!p) return '';
    if (/e\+/i.test(p)) return `+${8801700000000 + rowIndex}`;
    if (/^\d+(\.0+)?$/.test(p)) p = String(parseInt(p, 10));
    if (!p.startsWith('+')) p = `+${p}`;
    return p;
}

function shuffle(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        const t = a[i];
        a[i] = a[j];
        a[j] = t;
    }
    return a;
}

function requestWithRetry(method, url, body, params, maxAttempts = 3) {
    let res = null;
    const opts = Object.assign({ timeout: '30s' }, params || {});
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        if (method === 'GET') res = http.get(url, opts);
        else if (method === 'PUT') res = http.put(url, body, opts);
        else res = http.post(url, body, opts);
        if (res.status !== 0) return res;
        sleep(0.5 * attempt);
    }
    return res;
}

export default function () {
    const user = users[(__VU - 1) % users.length];

    // Small random think-time so 500 users don't stampede identical timing
    sleep(Math.random() * 1.5);

    // ===================================================
    // 1. Login
    // ===================================================
    const authRes = requestWithRetry(
        'POST',
        `${AUTH_URL}/v2/auth`,
        JSON.stringify({
            phoneNumber: user.phoneNumber,
            password: user.password,
            applicationChannel: 'WEB_APP',
        }),
        {
            headers: {
                'Content-Type': 'application/json',
                Accept: 'application/json',
            },
        }
    );

    check(authRes, { '1. Login': (r) => r.status === 200 });
    if (authRes.status !== 200) {
        loginFail.add(1);
        bookFail.add(1);
        console.log(`FAIL Login VU=${__VU} phone=${user.phoneNumber} status=${authRes.status}`);
        return;
    }
    loginSuccess.add(1);

    const headers = {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        Authorization: `Bearer ${authRes.json('data.access.token')}`,
    };

    // ===================================================
    // 2. Search Coach
    // ===================================================
    const searchRes = requestWithRetry(
        'POST',
        `${BOOKING_URL}/v2/coaches/search`,
        JSON.stringify({ date: JOURNEY_DATE, identifier: ROUTE_IDENTIFIER }),
        { headers }
    );

    const searchOk = searchRes.status === 200;
    check(searchRes, { '2. Search Coach': (r) => r.status === 200 });
    if (!searchOk) {
        bookFail.add(1);
        console.log(`FAIL Search VU=${__VU} status=${searchRes.status}`);
        return;
    }

    const coaches = (searchRes.json('data') || []).filter(
        (c) => (c.availableSeats === undefined || c.availableSeats > 0) && c.inactiveRoute !== 1
    );

    if (!coaches.length) {
        bookFail.add(1);
        check(null, { '3. Search Coach Details': () => false });
        check(null, { '4. Create Cart': () => false });
        check(null, { '5. Update Cart': () => false });
        check(null, { '6. Book': () => false });
        console.log(`FAIL VU=${__VU} no available coaches`);
        return;
    }

    // Spread users across coaches: each VU gets a unique random coach order
    const coachOrder = shuffle(coaches);
    const coachesToTry = coachOrder.slice(0, Math.min(MAX_COACH_TRIES, coachOrder.length));

    let booked = false;
    let ticketNo = null;
    let seatNo = null;
    let coachLabel = null;
    let detailsOk = false;
    let createOk = false;
    let updateOk = false;
    let failReason = 'no_seat_booked';

    for (let c = 0; c < coachesToTry.length && !booked; c++) {
        const coach = coachesToTry[c];
        const coachId = coach.id;
        coachLabel = coach.coachNo || coachId;

        // Realistic pause before opening a coach
        sleep(0.2 + Math.random() * 0.5);

        // ===================================================
        // 3. Search Coach Details
        // ===================================================
        const detailsRes = requestWithRetry(
            'GET',
            `${BOOKING_URL}/v3/coaches/${coachId}/seats`,
            null,
            { headers }
        );

        if (detailsRes.status !== 200) {
            failReason = `coach_details_${detailsRes.status}`;
            continue;
        }
        detailsOk = true;

        const coachData = detailsRes.json('data');
        const boardingPoints = coachData.boardingPoints || [];
        const droppingPoints = coachData.droppingPoints || [];
        const availableSeats = (coachData.seats || []).filter(
            (s) => String(s.status || '').toUpperCase() === 'AVAILABLE'
        );

        if (!boardingPoints.length || !droppingPoints.length || !availableSeats.length) {
            failReason = 'no_seats';
            continue;
        }

        // Random seat order — users don't all grab the same seat
        const seatOrder = shuffle(availableSeats).slice(0, Math.min(MAX_SEAT_TRIES, availableSeats.length));

        // ===================================================
        // 4. Create Cart
        // ===================================================
        const createRes = requestWithRetry(
            'POST',
            `${BOOKING_URL}/v3/carts`,
            JSON.stringify({ bookApplication: 'BUS', applicationChannel: 'WEB_APP' }),
            { headers }
        );

        if (createRes.status !== 201) {
            failReason = `create_cart_${createRes.status}`;
            continue;
        }
        createOk = true;

        const cartId = createRes.json('data.id');
        const updateUrl = `${BOOKING_URL}/v3/carts/${cartId}`;

        // ===================================================
        // 5. Update Cart — random available seats
        // ===================================================
        let selectedSeat = null;

        for (let i = 0; i < seatOrder.length; i++) {
            const seat = seatOrder[i];
            const updatePayload = {
                coachId: coachId,
                seatIdList: [String(seat.seatId)],
                boardingPoint: boardingPoints[0].reportingBranchId,
                droppingPoint: droppingPoints[0].reportingBranchId,
                cartType: 'DEPARTURE',
                journeyDate: JOURNEY_DATE,
                applicationChannel: 'WEB_APP',
                relatedCarts: [cartId],
                relatedCartId: cartId,
                passengerList: [
                    {
                        firstName: user.firstName,
                        lastName: user.lastName,
                        gender: 'MALE',
                        phoneNumber: user.phoneNumber,
                        email: user.email,
                    },
                ],
                remove: false,
                includeTravelInsurance: false,
            };

            const updateRes = requestWithRetry('PUT', updateUrl, JSON.stringify(updatePayload), { headers });
            if (updateRes.status !== 200) continue;

            const body = updateRes.json();
            const errors = body.errors || [];
            const data = body.data || {};

            if (errors.length === 0 && (data.seats || (data.coachSeatList || []).length > 0)) {
                selectedSeat = seat;
                updateOk = true;
                break;
            }
        }

        if (!selectedSeat) {
            failReason = 'seat_lock_failed';
            // Pick another random coach instead of scanning the whole bus
            continue;
        }

        // Short wait for seat lock to settle (keep total under 10m)
        sleep(1 + Math.random());

        // ===================================================
        // 6. Book
        // ===================================================
        const bookPayload = { cartId: cartId, applicationChannel: 'WEB_APP' };
        let bookRes = null;
        let bookOk = false;

        for (let b = 1; b <= 4 && !bookOk; b++) {
            bookRes = requestWithRetry(
                'POST',
                `${BOOKING_URL}/v3/carts/book`,
                JSON.stringify(bookPayload),
                {
                    headers,
                    responseCallback: http.expectedStatuses(200, 201, 400),
                }
            );

            if (bookRes.status === 200 || bookRes.status === 201) {
                bookOk = true;
                break;
            }

            let err = '';
            try {
                err = JSON.stringify(bookRes.json('errors') || []);
            } catch (e) {
                err = String(bookRes.body);
            }
            if (err.indexOf('BOOKING_CART_NOT_VALID_YET') === -1) break;
            sleep(1);
        }

        if (bookOk) {
            booked = true;
            seatNo = selectedSeat.seatNo;
            try {
                ticketNo = bookRes.json('data.ticketNo');
            } catch (e) {
                ticketNo = null;
            }
            failReason = null;
            break;
        }

        failReason = `book_${bookRes ? bookRes.status : 0}`;
    }

    check(null, { '3. Search Coach Details': () => detailsOk });
    check(null, { '4. Create Cart': () => createOk });
    check(null, { '5. Update Cart': () => updateOk });
    check(null, { '6. Book': () => booked });

    if (booked) {
        bookSuccess.add(1);
        console.log(
            `OK  VU=${__VU} phone=${user.phoneNumber} coach=${coachLabel} seat=${seatNo} ticket=${ticketNo}`
        );
    } else {
        bookFail.add(1);
        console.log(`FAIL VU=${__VU} phone=${user.phoneNumber} reason=${failReason}`);
    }
}

export function handleSummary(data) {
    const loginOk = (data.metrics.login_success && data.metrics.login_success.values.count) || 0;
    const loginBad = (data.metrics.login_fail && data.metrics.login_fail.values.count) || 0;
    const bookOk = (data.metrics.book_success && data.metrics.book_success.values.count) || 0;
    const bookBad = (data.metrics.book_fail && data.metrics.book_fail.values.count) || 0;

    const report = `
============================================================
500 CONCURRENT USERS — random coach + random seat
FLOW: Login → Search Coach → Coach Details → Create Cart → Update Cart → Book
============================================================
Login  success : ${loginOk}
Login  failed  : ${loginBad}
Book   success : ${bookOk}
Book   failed  : ${bookBad}
Total  users   : ${loginOk + loginBad}
============================================================
`;

    console.log(report);

    return {
        stdout: report,
        'booking-result.json': JSON.stringify(
            {
                login_success: loginOk,
                login_fail: loginBad,
                book_success: bookOk,
                book_fail: bookBad,
                total_users: loginOk + loginBad,
            },
            null,
            2
        ),
    };
}
