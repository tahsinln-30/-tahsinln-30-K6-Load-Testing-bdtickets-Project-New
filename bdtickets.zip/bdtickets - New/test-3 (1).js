import http from 'k6/http';
import { check, sleep } from 'k6';
import { SharedArray } from 'k6/data';
import { Counter } from 'k6/metrics';
import exec from 'k6/execution';

/*
 * Flow per user (matches UI on next.bdtickets.tech):
 * 1. Login
 * 2. Search Coach
 * 3. Search Coach Details
 * 4. Create Cart
 * 5. Update Cart          → Seat Select
 * 6. Proceed             → wait until cart is ready
 * 7. Book Only (1st)     → POST /v3/carts/book
 * 8. Book Only (2nd)     → POST /v3/carts/book again → seat booked
 *
 * If the current coach has no free seats (or all seats are locked),
 * automatically move to the next coach. When the coach list is exhausted,
 * re-run Search Coach. Continues until booking succeeds (or max rounds).
 */

// ============================================================
// LOAD TEST CONFIG  ← প্রতিবার টেস্টের আগে শুধু এখানে চেঞ্জ করুন
// ============================================================
// VUS          = একসাথে কয়জন ইউজার চলবে
// ITERATIONS   = প্রতি VU কয়বার বুকিং চেষ্টা করবে
// MAX_DURATION = টেস্ট কতক্ষণ চলবে (যেমন: '1m', '5m', '10m')
// ============================================================
const VUS = 100000;
const ITERATIONS = 1;
const MAX_DURATION = '5m';
// ============================================================

export const options = {
    scenarios: {
        concurrent_booking: {
            executor: 'per-vu-iterations',
            vus: VUS,
            iterations: ITERATIONS,
            maxDuration: MAX_DURATION,
            gracefulStop: '30s',
        },
    },
};

export function setup() {
    console.log(
        `LOAD CONFIG → VUS=${VUS} | ITERATIONS=${ITERATIONS} (per VU) | MAX_DURATION=${MAX_DURATION}`
    );
    return {};
}

const AUTH_URL = 'https://api1.bdtickets.tech:20100';
const BOOKING_URL = 'https://api1.bdtickets.tech:20102';

// Keep each request short so one slow call cannot eat the whole maxDuration
const REQUEST_TIMEOUT = '20s';
const MAX_RETRIES = 2;
const MAX_COACHES_PER_SEARCH = 5;
const MAX_SEAT_TRIES = 4;

// Journey dates (API expects YYYY-MM-DD)
const JOURNEY_DATES = [
    '2026-09-30',
    '2026-10-01',
    '2026-10-02',
    '2026-10-03',
    '2026-10-04',
    '2026-10-05',
];

// Routes: Dhaka ↔ destinations (API route identifiers)
const ROUTE_IDENTIFIERS = [
    'dhaka-to-coxs-bazar',
    'dhaka-to-bandarban',
    'dhaka-to-chittagong',
    'dhaka-to-sylhet',
    'dhaka-to-nalta',
    'dhaka-to-jessore',
    'dhaka-to-khulna',
    'coxs-bazar-to-dhaka',
    'bandarban-to-dhaka',
    'chittagong-to-dhaka',
    'sylhet-to-dhaka',
    'nalta-to-dhaka',
    'jessore-to-dhaka',
    'khulna-to-dhaka',
];

function pickRandom(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

const loginSuccess = new Counter('login_success');
const loginFail = new Counter('login_fail');
const searchSuccess = new Counter('search_success');
const searchFail = new Counter('search_fail');
const searchNoCoach = new Counter('search_no_coach');
const reachedBook = new Counter('reached_book');
const bookSuccess = new Counter('book_success');
const bookFail = new Counter('book_fail');

const USERS_CSV = __ENV.USERS_CSV || 'loadtest-users.csv';

const users = new SharedArray('users', function () {
    const text = open(USERS_CSV);
    const lines = text.replace(/^\uFEFF/, '').trim().split(/\r?\n/);
    if (lines.length < 2) throw new Error(`No users found in ${USERS_CSV}`);

    const headers = lines[0].split(',').map((h) => h.trim());
    const phoneIdx = headers.indexOf('phoneNumber');
    const passIdx = headers.indexOf('password');
    const idIdx = headers.indexOf('userId');
    if (phoneIdx < 0 || passIdx < 0) {
        throw new Error('CSV must have phoneNumber and password columns');
    }

    const parsed = [];
    for (let i = 1; i < lines.length; i++) {
        const cols = lines[i].split(',');
        if (cols.length < 2) continue;

        const phone = normalizePhone((cols[phoneIdx] || '').trim(), i);
        const password = (cols[passIdx] || '').trim();
        if (!phone || !password) continue;

        parsed.push({
            phoneNumber: phone,
            password: password,
            userId: idIdx >= 0 ? (cols[idIdx] || '').trim() : '',
            email: `loadtest${i}@example.com`,
            firstName: 'Load',
            lastName: `User${i}`,
        });
    }

    if (!parsed.length) throw new Error(`Failed to parse users from ${USERS_CSV}`);
    console.log(`Loaded ${parsed.length} users from ${USERS_CSV}`);
    return parsed;
});

function normalizePhone(raw, rowIndex) {
    let p = String(raw || '').trim();
    if (!p) return '';
    if (/e\+/i.test(p)) return `+${8801700000000 + rowIndex}`;
    if (/^\d+(\.0+)?$/.test(p)) p = String(parseInt(p, 10));
    if (!p.startsWith('+')) p = `+${p}`;
    return p;
}

function requestWithRetry(method, url, body, params, maxAttempts = MAX_RETRIES) {
    let res = null;
    const opts = Object.assign({ timeout: REQUEST_TIMEOUT }, params || {});
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        if (method === 'GET') res = http.get(url, opts);
        else if (method === 'PUT') res = http.put(url, body, opts);
        else res = http.post(url, body, opts);
        if (res.status !== 0) return res;
        sleep(0.5 * attempt);
    }
    return res;
}

function rotateSeats(seats, vu) {
    if (!seats.length) return seats;
    const offset = (vu - 1) % seats.length;
    return seats.slice(offset).concat(seats.slice(0, offset));
}

function shuffle(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        const t = a[i];
        a[i] = a[j];
        a[j] = t;
    }
    return a;
}

// UI "Proceed": poll cart until seat lock is ready for Book Only
function proceedCartReady(headers, cartId, maxPoll = 5) {
    for (let i = 0; i < maxPoll; i++) {
        const res = requestWithRetry(
            'GET',
            `${BOOKING_URL}/v3/carts/${cartId}`,
            null,
            { headers }
        );
        if (res.status === 200) {
            const data = res.json('data') || {};
            const seats = data.coachSeatList || data.seats || [];
            const totalSeats = Number(data.totalSeats || seats.length || 0);
            const locked = !!(data.seatLockId || data.expireDateTime);
            if (totalSeats > 0 || locked || seats.length > 0) {
                return { ready: true, res };
            }
        }
        sleep(0.4);
    }
    return { ready: false, res: null };
}

// UI "Book Only" click
function clickBookOnly(headers, cartId) {
    return requestWithRetry(
        'POST',
        `${BOOKING_URL}/v3/carts/book`,
        JSON.stringify({ cartId: cartId, applicationChannel: 'WEB_APP' }),
        {
            headers,
            responseCallback: http.expectedStatuses(200, 201, 400),
        }
    );
}

export default function () {
    // Unique user per booking attempt across shared-iterations
    const userIndex = exec.scenario.iterationInTest % users.length;
    const user = users[userIndex];
    // Light stagger — keep short so booking can finish inside maxDuration
    sleep(Math.random() * 0.3);

    // ===================================================
    // 1. Login
    // ===================================================
    const authRes = requestWithRetry(
        'POST',
        `${AUTH_URL}/v2/auth`,
        JSON.stringify({
            phoneNumber: user.phoneNumber,
            password: user.password,
            applicationChannel: 'WEB_APP',
        }),
        {
            headers: {
                'Content-Type': 'application/json',
                Accept: 'application/json',
            },
        }
    );

    check(authRes, { '1. Login': (r) => r.status === 200 });
    if (authRes.status !== 200) {
        loginFail.add(1);
        // Do NOT count login fail as book fail — that hides real book metrics
        if (__VU % 500 === 0) {
            console.log(`FAIL 1.Login VU=${__VU} phone=${user.phoneNumber} status=${authRes.status}`);
        }
        return;
    }
    loginSuccess.add(1);

    const headers = {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        Authorization: `Bearer ${authRes.json('data.access.token')}`,
    };

    let booked = false;
    let ticketNo = null;
    let seatNo = null;
    let coachLabel = null;
    let failReason = 'unknown';
    let journeyDate = null;
    let routeIdentifier = null;

    let didSearch = false;
    let didDetails = false;
    let didCreate = false;
    let didUpdate = false;
    let didProceed = false;
    let didBookOnly1 = false;
    let didBookOnly2 = false;

    // Pick route+date once; only change when search finds no coaches / hard fail
    journeyDate = pickRandom(JOURNEY_DATES);
    routeIdentifier = pickRandom(ROUTE_IDENTIFIERS);

    // Loop until booking succeeds: seats gone on a coach → next coach; list empty → re-search
    const maxSearchRounds = 30;
    let searchRound = 0;

    while (!booked && searchRound < maxSearchRounds) {
        searchRound++;

        // -------------------------------------------------
        // 2. Search Coach
        // -------------------------------------------------
        const searchRes = requestWithRetry(
            'POST',
            `${BOOKING_URL}/v2/coaches/search`,
            JSON.stringify({ date: journeyDate, identifier: routeIdentifier }),
            { headers }
        );

        didSearch = true;
        if (searchRes.status !== 200) {
            failReason = `search_${searchRes.status}`;
            searchFail.add(1);
            if (searchRound <= 2) {
                console.log(
                    `SEARCH RESULT ✗ VU=${__VU} round=${searchRound} route=${routeIdentifier} date=${journeyDate} status=${searchRes.status} err=${searchRes.error || ''} coaches=0`
                );
            }
            journeyDate = pickRandom(JOURNEY_DATES);
            routeIdentifier = pickRandom(ROUTE_IDENTIFIERS);
            sleep(0.2);
            continue;
        }

        // Prefer coaches that still show available seats in search
        const allCoaches = (searchRes.json('data') || []).filter(
            (c) => c.inactiveRoute !== 1 && Number(c.availableSeats || 0) > 0
        );

        if (!allCoaches.length) {
            searchNoCoach.add(1);
            failReason = 'no_coach';
            if (searchRound <= 2) {
                console.log(
                    `SEARCH RESULT ✓ VU=${__VU} round=${searchRound} route=${routeIdentifier} date=${journeyDate} coaches=0`
                );
            }
            journeyDate = pickRandom(JOURNEY_DATES);
            routeIdentifier = pickRandom(ROUTE_IDENTIFIERS);
            sleep(0.2);
            continue;
        }

        searchSuccess.add(1);
        const coachSummary = allCoaches
            .slice(0, 8)
            .map((c) => `${c.coachNo || c.id}(${c.availableSeats})`)
            .join(', ');
        console.log(
            `SEARCH RESULT ✓ VU=${__VU} round=${searchRound} route=${routeIdentifier} date=${journeyDate} coaches=${allCoaches.length} list=[${coachSummary}${allCoaches.length > 8 ? ', ...' : ''}]`
        );

        // Prefer fuller coaches first, then shuffle top set
        allCoaches.sort((a, b) => Number(b.availableSeats || 0) - Number(a.availableSeats || 0));
        let coaches = shuffle(allCoaches.slice(0, Math.min(12, allCoaches.length))).slice(
            0,
            MAX_COACHES_PER_SEARCH
        );

        for (let c = 0; c < coaches.length && !booked; c++) {
            const coach = coaches[c];
            const coachId = coach.id;
            coachLabel = coach.coachNo || coachId;

            // -------------------------------------------------
            // 3. Search Coach Details
            // -------------------------------------------------
            const detailsRes = requestWithRetry(
                'GET',
                `${BOOKING_URL}/v3/coaches/${coachId}/seats`,
                null,
                { headers }
            );

            if (detailsRes.status !== 200) {
                failReason = `details_${detailsRes.status}`;
                continue;
            }
            didDetails = true;

            const coachData = detailsRes.json('data') || {};
            const boardingPoints = coachData.boardingPoints || [];
            const droppingPoints = coachData.droppingPoints || [];
            let availableSeats = (coachData.seats || []).filter(
                (s) => String(s.status || '').toUpperCase() === 'AVAILABLE'
            );

            if (!boardingPoints.length || !droppingPoints.length || !availableSeats.length) {
                failReason = 'coach_full';
                continue; // → next coach
            }

            availableSeats = shuffle(availableSeats).slice(0, MAX_SEAT_TRIES);

            // -------------------------------------------------
            // 4. Create Cart
            // -------------------------------------------------
            const createRes = requestWithRetry(
                'POST',
                `${BOOKING_URL}/v3/carts`,
                JSON.stringify({ bookApplication: 'BUS', applicationChannel: 'WEB_APP' }),
                { headers }
            );

            if (createRes.status !== 201) {
                failReason = `create_cart_${createRes.status}`;
                continue;
            }
            didCreate = true;

            const cartId = createRes.json('data.id');
            const updateUrl = `${BOOKING_URL}/v3/carts/${cartId}`;

            // -------------------------------------------------
            // 5. Seat Select (Update Cart — lock seat + passenger)
            // -------------------------------------------------
            let selectedSeat = null;

            for (let i = 0; i < availableSeats.length; i++) {
                const seat = availableSeats[i];
                const updatePayload = {
                    coachId: coachId,
                    seatIdList: [String(seat.seatId)],
                    boardingPoint: boardingPoints[0].reportingBranchId,
                    droppingPoint: droppingPoints[0].reportingBranchId,
                    cartType: 'DEPARTURE',
                    journeyDate: journeyDate,
                    applicationChannel: 'WEB_APP',
                    relatedCarts: [cartId],
                    relatedCartId: cartId,
                    passengerList: [
                        {
                            firstName: user.firstName,
                            lastName: user.lastName,
                            gender: 'MALE',
                            phoneNumber: user.phoneNumber,
                            email: user.email,
                        },
                    ],
                    remove: false,
                    includeTravelInsurance: false,
                };

                const updateRes = requestWithRetry('PUT', updateUrl, JSON.stringify(updatePayload), {
                    headers,
                });

                if (updateRes.status !== 200) continue;

                const body = updateRes.json();
                const errors = body.errors || [];
                const data = body.data || {};

                if (errors.length === 0 && (data.seats || (data.coachSeatList || []).length > 0)) {
                    selectedSeat = seat;
                    didUpdate = true;
                    break;
                }
                // SEAT_BEING_PROCESSED_BY_OTHERS / unavailable → try next seat
            }

            if (!selectedSeat) {
                failReason = 'coach_seats_exhausted';
                continue; // → next coach
            }

            sleep(0.2);

            // -------------------------------------------------
            // 6. Proceed (UI: click Proceed after seat + passenger)
            // -------------------------------------------------
            const proceed = proceedCartReady(headers, cartId);
            didProceed = proceed.ready;
            if (!proceed.ready) {
                failReason = 'proceed_cart_not_ready';
                continue;
            }

            // -------------------------------------------------
            // 7 + 8. Book Only (1st + 2nd click)
            // -------------------------------------------------
            reachedBook.add(1);
            let bookRes = clickBookOnly(headers, cartId);
            didBookOnly1 = true;
            let bookOk = bookRes.status === 200 || bookRes.status === 201;

            sleep(0.3);
            const bookRes2 = clickBookOnly(headers, cartId);
            didBookOnly2 = true;

            if (bookRes2.status === 200 || bookRes2.status === 201) {
                bookOk = true;
                bookRes = bookRes2;
            } else if (!bookOk) {
                let err = '';
                try {
                    err = JSON.stringify(bookRes2.json('errors') || bookRes.json('errors') || []);
                } catch (e) {
                    err = String((bookRes2 && bookRes2.body) || (bookRes && bookRes.body) || '');
                }
                if (err.indexOf('BOOKING_CART_NOT_VALID_YET') !== -1) {
                    sleep(0.8);
                    const bookRes3 = clickBookOnly(headers, cartId);
                    if (bookRes3.status === 200 || bookRes3.status === 201) {
                        bookOk = true;
                        bookRes = bookRes3;
                    }
                }
            }

            if (bookOk) {
                booked = true;
                seatNo = selectedSeat.seatNo;
                try {
                    ticketNo = bookRes.json('data.ticketNo');
                } catch (e) {
                    ticketNo = null;
                }
                failReason = null;
                break;
            }

            failReason = `book_${bookRes2 ? bookRes2.status : bookRes ? bookRes.status : 0}`;
            try {
                const errBody = bookRes2.json('errors') || bookRes.json('errors');
                if (errBody) failReason += `:${JSON.stringify(errBody).slice(0, 120)}`;
            } catch (e) {}
            // Seat was selected but book failed → try next coach
        }

        if (!booked) {
            sleep(0.3);
        }
    }

    check(null, { '2. Search Coach': () => didSearch });
    check(null, { '3. Search Coach Details': () => didDetails });
    check(null, { '4. Create Cart': () => didCreate });
    check(null, { '5. Seat Select (Update Cart)': () => didUpdate });
    check(null, { '6. Proceed': () => didProceed });
    check(null, { '7. Book Only #1': () => didBookOnly1 });
    check(null, { '8. Book Only #2': () => didBookOnly2 });
    check(null, { '9. Booked': () => booked });

    if (booked) {
        bookSuccess.add(1);
        console.log(
            `OK  VU=${__VU} phone=${user.phoneNumber} route=${routeIdentifier} date=${journeyDate} coach=${coachLabel} seat=${seatNo} ticket=${ticketNo}`
        );
    } else {
        bookFail.add(1);
        console.log(
            `FAIL VU=${__VU} phone=${user.phoneNumber} route=${routeIdentifier} date=${journeyDate} reason=${failReason}`
        );
    }
}

export function handleSummary(data) {
    const loginOk = (data.metrics.login_success && data.metrics.login_success.values.count) || 0;
    const loginBad = (data.metrics.login_fail && data.metrics.login_fail.values.count) || 0;
    const searchOk = (data.metrics.search_success && data.metrics.search_success.values.count) || 0;
    const searchBad = (data.metrics.search_fail && data.metrics.search_fail.values.count) || 0;
    const noCoach = (data.metrics.search_no_coach && data.metrics.search_no_coach.values.count) || 0;
    const reached = (data.metrics.reached_book && data.metrics.reached_book.values.count) || 0;
    const bookOk = (data.metrics.book_success && data.metrics.book_success.values.count) || 0;
    const bookBad = (data.metrics.book_fail && data.metrics.book_fail.values.count) || 0;

    const report = `
============================================================
FLOW: Login → Search → Details → Cart → Seat Select → Proceed → Book Only ×2
============================================================
Login  success     : ${loginOk}
Login  failed      : ${loginBad}
Search with coach  : ${searchOk}
Search empty/0     : ${noCoach}
Search HTTP fail   : ${searchBad}
Reached Book Only  : ${reached}
Book   success     : ${bookOk}
Book   failed      : ${bookBad}
============================================================
Note: Book failed counts only users who logged in but did not book.
Login failures are separate (API overload / timeout).
============================================================
`;

    console.log(report);

    return {
        stdout: report,
        'booking-result.json': JSON.stringify(
            {
                login_success: loginOk,
                login_fail: loginBad,
                search_with_coach: searchOk,
                search_no_coach: noCoach,
                search_fail: searchBad,
                reached_book: reached,
                book_success: bookOk,
                book_fail: bookBad,
            },
            null,
            2
        ),
    };
}
